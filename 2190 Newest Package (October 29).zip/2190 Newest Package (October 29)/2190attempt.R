library(readxl)
library(dplyr)
merge_function <- function (xls){
  cnt = 1
  transformed <- data.frame()
  while(cnt != 45){
      untransformed <- read_xls(xls, paste("Ward",cnt,sep=''))
      untransformed$ward <- rep(cnt,nrow(untransformed))
      untransformed <- dplyr::filter(untransformed, !grepl(paste("Ward",cnt,"Totals"), Candidate))
      untransformed <- subset(untransformed, select=c("Candidate","Total"))
      untransformed$Ward <- rep(cnt,nrow(untransformed)) 
      transformed <- rbind(untransformed, transformed)
      cnt = cnt + 1
  }
}
xls <- "~/Downloads/2190projdata/MAYOR.xls"
merge_function(xls)
shp_data <- read.csv("~/Downloads/wardshp_data.csv")
colnames(shp_data)[6] <- "Ward"
shp_data <- subset(shp_data, select=c("X","Y","NAME","Ward"))
final <- merge(transformed,shp_data, by="Ward")
write.csv(final,'~/Documents/transformed.csv')
