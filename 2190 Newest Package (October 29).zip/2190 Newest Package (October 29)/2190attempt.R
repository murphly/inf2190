library(readxl)
library(dplyr)

#don't know why I wrote a function when you really only need to do this once..
xls <- "~/Downloads/2190projdata/MAYOR.xls"
cnt = 1
transformed <- data.frame()
while(cnt != 45){
      untransformed <- read_xls(xls, paste("Ward",cnt,sep=''))
      untransformed$ward <- rep(cnt,nrow(untransformed))
      untransformed <- dplyr::filter(untransformed, !grepl(paste("Ward",cnt,"Totals"), Candidate))
      untransformed <- subset(untransformed, select=c("Candidate","Total"))
      untransformed$Ward <- rep(cnt,nrow(untransformed)) 
      transformed <- rbind(untransformed, transformed)
      cnt = cnt + 1
}
# create a dataframe of shape data and merge it with the dataframe created through the 
# user generated function
shp_data <- read.csv("~/Downloads/wardshp_data.csv")
colnames(shp_data)[6] <- "Ward"
shp_data <- subset(shp_data, select=c("X","Y","NAME","Ward"))
subfinal <- merge(transformed,shp_data, by="Ward")

#create a dataframe of km2 size data and merge it with subfinal
wardareas <- read.csv("~/Downloads/wardareas.csv")
wardareas <- subset(wardareas, select=c("Ward","Area"))
final <- merge(subfinal,wardareas, by="Ward")

#write the final df to csv
write.csv(final,'~/Documents/transformed.csv')

